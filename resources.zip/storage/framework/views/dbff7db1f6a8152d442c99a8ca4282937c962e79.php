<?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('css'); ?>
  <body> 
    <div id="app" class="">
        <!-- navbar -->
        <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('banner'); ?>
        <!-- content -->
        <?php echo $__env->yieldContent('content'); ?>
      </div>
    <!-- footer -->
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>
  </body>
</html><?php /**PATH C:\Users\Yusuf Sodiq\Desktop\expenseng\resources\views/layouts/master.blade.php ENDPATH**/ ?>