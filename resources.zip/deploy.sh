#i/bin/sh
composer clearcache
composer install
php artisan serve